# DispatchAnswer — "Call me now" demo landing page

A Next.js landing page where a visitor enters their phone number and your
Retell AI demo agent calls them within seconds. Built to deploy on Vercel.

## How it works (the important part)

```
Visitor types number  →  /api/demo-call (your serverless function)
                            ├─ validates + normalizes the number (US, E.164)
                            ├─ anti-abuse: per-number cooldown + per-IP daily cap
                            └─ calls Retell:  POST /v2/create-phone-call
                                                 → Retell dials the visitor
```

**Why a backend function instead of calling Retell from the browser:** your
Retell API key is a secret. If the browser called Retell directly, anyone could
view-source, steal the key, and rack up call charges on your account. The key
lives only on the server (in `RETELL_API_KEY`), never shipped to the browser.

---

## Part 1 — Retell setup (starting from scratch)

You need three things from Retell: an **agent**, an **outbound phone number**,
and an **API key**.

### 1. Create the demo agent
1. Sign in at https://dashboard.retellai.com
2. Go to **Agents → + Create Agent** (start from a blank or "Single Prompt" template).
3. Give it a prompt that role-plays your service. For a contractor demo, something like:
   > "You are the after-hours answering service for an HVAC company. A homeowner is
   > calling because their heat/AC stopped working. Greet them warmly, ask what's
   > going on, get their name, address, and the best callback number, let them know a
   > technician will follow up first thing, and reassure them. Keep it short and human."
4. Pick a voice you like, then **Publish** the agent.
5. Copy the **Agent ID** (looks like `agent_xxxxxxxx`). You'll need it for `RETELL_AGENT_ID`.

### 2. Get an outbound phone number
1. Go to **Phone Numbers → + Add Number**.
2. Buy a Retell number (cheapest path) **or** import a number you own (Twilio/SIP).
3. When prompted, set the agent for **outbound** calls to the demo agent you just made.
   (If you bind the number to the agent here, you can leave `RETELL_AGENT_ID` blank —
   the code also passes the agent explicitly via `override_agent_id`, so either way works.)
4. Copy the number in **E.164 format** (e.g. `+15165551234`). This is `RETELL_FROM_NUMBER`.

> Note: numbers purchased from Retell can only call **US** destinations. The form
> and backend are already restricted to US numbers to match this.

### 3. Get your API key
1. Go to **Settings → API Keys → Create**.
2. Copy it (starts with `key_`). This is `RETELL_API_KEY`. Treat it like a password.

---

## Part 2 — Run it locally (optional, to test before deploying)

1. Install [Node.js](https://nodejs.org) 18+ if you don't have it.
2. In this folder:
   ```bash
   npm install
   cp .env.example .env.local
   ```
3. Open `.env.local` and fill in `RETELL_API_KEY`, `RETELL_FROM_NUMBER`, and
   `RETELL_AGENT_ID`.
4. Start it:
   ```bash
   npm run dev
   ```
5. Open http://localhost:3000, enter your own cell number, and you should get a call.

---

## Part 3 — Deploy to Vercel

### Option A — drag-and-drop / Git (easiest)
1. Push this folder to a GitHub repo (or use the Vercel CLI / dashboard import).
2. At https://vercel.com → **Add New → Project**, import the repo.
3. Before the first deploy, add the environment variables (next section).
4. Click **Deploy**. Vercel auto-detects Next.js — no config needed.

### Option B — Vercel CLI
```bash
npm i -g vercel
vercel            # follow prompts to link the project
vercel --prod     # deploy to production
```

### Environment variables (set these in Vercel)
Vercel dashboard → your project → **Settings → Environment Variables**. Add:

| Variable | Required | Value |
|---|---|---|
| `RETELL_API_KEY` | ✅ | your `key_...` |
| `RETELL_FROM_NUMBER` | ✅ | your outbound number, e.g. `+15165551234` |
| `RETELL_AGENT_ID` | optional | `agent_...` (skip if the number is already bound to the agent) |
| `UPSTASH_REDIS_REST_URL` | recommended | from Upstash (see below) |
| `UPSTASH_REDIS_REST_TOKEN` | recommended | from Upstash |
| `DEMO_COOLDOWN_MINUTES` | optional | default `10` |
| `DEMO_IP_DAILY_LIMIT` | optional | default `5` |

After adding/changing env vars, **redeploy** so they take effect.

---

## Part 4 — Anti-abuse (so the demo can't burn your Retell minutes)

Every demo call costs you Retell minutes, so the backend enforces two limits:

- **Per-number cooldown** — the same phone number can't trigger another call for
  `DEMO_COOLDOWN_MINUTES` (default 10).
- **Per-IP daily cap** — a single visitor IP can trigger at most
  `DEMO_IP_DAILY_LIMIT` calls per day (default 5).

These work out of the box using in-memory storage, **but** serverless functions
restart often, which resets in-memory counters — so a determined abuser could get
around them. For durable limits that survive restarts, add a free Redis store:

1. Create a free database at https://upstash.com (Redis).
2. Copy the **REST URL** and **REST Token**.
3. Set `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN` in Vercel.

The code auto-detects these and switches to durable rate limiting. No other changes needed.

**Other safeguards to consider later:** add a CAPv (e.g. Cloudflare Turnstile / hCaptcha)
to the form, and/or require an SMS opt-in checkbox for TCPA hygiene.

---

## Customizing

- **Copy / branding:** edit `app/page.js` (headline, bullets, button text) and
  `app/globals.css` (colors — the brand blue is `--brand`).
- **What the agent says:** that's in the Retell dashboard, not this code.
- **Tagging calls:** the backend already sends `metadata: { source: "landing_page_demo" }`
  so you can filter demo calls in Retell's call history. You can also pass dynamic
  variables to the agent by adding a `retell_llm_dynamic_variables` object to the
  payload in `app/api/demo-call/route.js`.

## File map
```
app/page.js                  Landing page + the "Call me now" form
app/layout.js                Page shell + SEO metadata
app/globals.css              Styling
app/api/demo-call/route.js   Serverless endpoint that calls Retell
lib/rateLimit.js             Cooldown + IP cap (Upstash or in-memory)
.env.example                 Copy to .env.local and fill in
```

## Troubleshooting
- **No call comes through:** check the Vercel function logs (Deployments → your
  deploy → Functions → `/api/demo-call`). A `401` means a bad `RETELL_API_KEY`; a
  `402`/`payment` error means add credit in Retell; a `400` usually means the
  `from_number` isn't a number Retell recognizes.
- **"Demo is temporarily unavailable":** `RETELL_API_KEY` or `RETELL_FROM_NUMBER`
  isn't set in Vercel (or you didn't redeploy after adding them).
- **Call connects but agent is silent / wrong:** the number isn't bound to your
  agent and `RETELL_AGENT_ID` is blank — set `RETELL_AGENT_ID`.

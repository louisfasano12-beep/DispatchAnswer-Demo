import { numberInCooldown, ipOverDailyLimit } from "../../../lib/rateLimit";

// Always run fresh; never cache this route.
export const dynamic = "force-dynamic";

/**
 * Normalize a user-typed US phone number to E.164 (+1XXXXXXXXXX).
 * Returns null if it doesn't look like a valid US number.
 */
function toE164US(raw) {
  const digits = (raw || "").replace(/\D/g, "");
  if (digits.length === 10) return `+1${digits}`;
  if (digits.length === 11 && digits.startsWith("1")) return `+${digits}`;
  return null;
}

function getClientIp(req) {
  const fwd = req.headers.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0].trim();
  return req.headers.get("x-real-ip") || "unknown";
}

export async function POST(req) {
  // --- Parse input ---
  let body;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Invalid request." }, { status: 400 });
  }

  const toNumber = toE164US(body.phone);
  if (!toNumber) {
    return Response.json(
      { error: "Please enter a valid 10-digit US phone number." },
      { status: 400 }
    );
  }

  // --- Config / env ---
  const apiKey = process.env.RETELL_API_KEY;
  const fromNumber = process.env.RETELL_FROM_NUMBER;
  const agentId = process.env.RETELL_AGENT_ID; // optional if number is bound
  const cooldownMinutes = Number(process.env.DEMO_COOLDOWN_MINUTES || 10);
  const ipDailyLimit = Number(process.env.DEMO_IP_DAILY_LIMIT || 5);

  if (!apiKey || !fromNumber) {
    console.error("Missing RETELL_API_KEY or RETELL_FROM_NUMBER env vars.");
    return Response.json(
      { error: "Demo is temporarily unavailable. Please try again later." },
      { status: 500 }
    );
  }

  // --- Anti-abuse ---
  try {
    const ip = getClientIp(req);
    if (await ipOverDailyLimit(ip, ipDailyLimit)) {
      return Response.json(
        { error: "Daily demo limit reached. Please try again tomorrow." },
        { status: 429 }
      );
    }
    if (await numberInCooldown(toNumber, cooldownMinutes)) {
      return Response.json(
        {
          error: `We just called that number. Give it ${cooldownMinutes} minutes before requesting another demo.`,
        },
        { status: 429 }
      );
    }
  } catch (e) {
    // Don't let a rate-limit backend hiccup block the demo entirely.
    console.error("Rate limit check failed (continuing):", e);
  }

  // --- Trigger the Retell outbound call ---
  const payload = {
    from_number: fromNumber,
    to_number: toNumber,
    metadata: { source: "landing_page_demo" },
  };
  if (agentId) payload.override_agent_id = agentId;

  try {
    const retellRes = await fetch(
      "https://api.retellai.com/v2/create-phone-call",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      }
    );

    if (!retellRes.ok) {
      const detail = await retellRes.text();
      console.error("Retell API error", retellRes.status, detail);
      return Response.json(
        { error: "Could not place the call right now. Please try again." },
        { status: 502 }
      );
    }

    const call = await retellRes.json();
    return Response.json({ ok: true, call_id: call.call_id });
  } catch (e) {
    console.error("Retell request failed:", e);
    return Response.json(
      { error: "Could not place the call right now. Please try again." },
      { status: 502 }
    );
  }
}
